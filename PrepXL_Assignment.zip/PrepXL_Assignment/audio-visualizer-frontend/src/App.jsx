import CircularVisualizer from "./components/CircularVisualizer";

function App() {
  return (
    <div style={{ background: "#0f172a", height: "100vh" }}>
      <CircularVisualizer />
    </div>
  );
}

export default App;
