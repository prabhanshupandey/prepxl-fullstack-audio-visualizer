let socket;

export function connectSocket(onMessage) {
  socket = new WebSocket("ws://localhost:8080/ws/audio");

  socket.onmessage = (event) => {
    onMessage(event.data);
  };
}

export function sendAudioChunk(chunk) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(chunk);
  }
}
