export async function initAudio() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const source = audioContext.createMediaStreamSource(stream);

  const analyser = audioContext.createAnalyser();
  analyser.fftSize = 256;

  source.connect(analyser);

  return { analyser };
}
