import { useEffect, useState } from "react";
import { initAudio } from "../services/audioService";

export default function useAudioAnalyzer() {
  const [analyser, setAnalyser] = useState(null);

  useEffect(() => {
    initAudio().then(({ analyser }) => {
      setAnalyser(analyser);
    });
  }, []);

  return analyser;
}
