import { useEffect, useRef, useState } from "react";
import useAudioAnalyzer from "../hooks/useAudioAnalyzer";
import useSpeechRecognition from "../hooks/useSpeechRecognition";
import "../styles/visualizer.css";

export default function CircularVisualizer() {
  const canvasRef = useRef(null);
  const analyser = useAudioAnalyzer();
  const liveText = useSpeechRecognition();

  const [messages, setMessages] = useState([]);
  const lastProcessedRef = useRef("");

  // 🔊 Bot voice
  function speak(text) {
    if (!text) return;
    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = "hi-IN";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(msg);
  }

  // 🤖 Reply logic (Hindi + English)
  function getReply(text) {
    const t = text.toLowerCase();

    if (t.includes("hello") || t.includes("hi"))
      return "Hello! Aap kaise ho?";
    
    if (t.includes("aap mere bare me kuch bata skti ho") || t.includes("Pandey ji aap bahute sunder ho"))
      return "Hello! Aap kaise ho?";

    if (t.includes("naam") || t.includes("name"))
      return "Mera naam Sri hai.";

    if (t.includes("kaise") || t.includes("how are you"))
      return "Main bilkul theek hoon.";

    if (t.includes("kya kar") || t.includes("what are you doing"))
      return "Main aapki awaaz sun kar jawab deta hoon.";

    if (t.includes("thanks") || t.includes("thank you"))
      return "Aapka swagat hai.";

    if (t.includes("bye"))
      return "Bye! Phir milenge.";

    return "Pandey ji aap bahut sunder ho.";
  }

  // 🎤 Speech → Conversation
  useEffect(() => {
    if (!liveText || liveText.length < 3) return;
    if (liveText === lastProcessedRef.current) return;

    lastProcessedRef.current = liveText;

    const userMsg = { from: "You", text: liveText };
    const botReply = getReply(liveText);
    const botMsg = { from: "Bot", text: botReply };

    setMessages(prev => [...prev, userMsg, botMsg]);
    speak(botReply);
  }, [liveText]);

  // 🎨 Circular Visualizer
  useEffect(() => {
    if (!analyser) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    const radius = 120;

    function draw() {
      requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const cx = canvas.width / 2;
      const cy = canvas.height / 2;

      dataArray.forEach((value, i) => {
        const angle = (i / bufferLength) * Math.PI * 2;

        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius);
        ctx.lineTo(
          cx + Math.cos(angle) * (radius + value),
          cy + Math.sin(angle) * (radius + value)
        );
        ctx.strokeStyle = `hsl(${i * 4},100%,60%)`;
        ctx.lineWidth = 3;
        ctx.stroke();
      });
    }

    draw();
    return () => window.removeEventListener("resize", resizeCanvas);
  }, [analyser]);

  return (
    <div className="visualizer-container">
      <canvas ref={canvasRef}></canvas>

      <div className="chat-box">
        {messages.map((m, i) => (
          <p key={i}>
            <b>{m.from}:</b> {m.text}
          </p>
        ))}
      </div>
    </div>
  );
}
