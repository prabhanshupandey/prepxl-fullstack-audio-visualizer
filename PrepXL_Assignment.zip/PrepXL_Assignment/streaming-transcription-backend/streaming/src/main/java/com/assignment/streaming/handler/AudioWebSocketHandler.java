package com.assignment.streaming.handler;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class AudioWebSocketHandler extends TextWebSocketHandler {

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        System.out.println("Received: " + message.getPayload());
        session.sendMessage(new TextMessage("Listening..."));
    }

    @Override
protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) {
    System.out.println("Audio chunk received: " + message.getPayloadLength());
}

}
